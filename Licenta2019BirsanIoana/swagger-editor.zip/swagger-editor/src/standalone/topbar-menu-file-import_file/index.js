import ImportFileMenuItem from "./components/ImportFileMenuItem"

export default {
  components: {
    ImportFileMenuItem
  }
}